package com.chainspower.mytab

import android.annotation.SuppressLint
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.TabLayout
import android.text.Html
import android.text.Spanned
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mTvContent.setText(fromHtml("<p>尊敬的GMW用户：</p>\\n<p>&nbsp; &nbsp; &nbsp;您好！</p>\\n<p>&nbsp; &nbsp; &nbsp;目前GMW处于内测阶段，为了不影响用户体验，我们正在积极的进行技术升级与维护。</p>"))
        mTabLayout.addOnTabSelectedListener(object :TabLayout.OnTabSelectedListener{
            override fun onTabReselected(p0: TabLayout.Tab?) {
            }

            override fun onTabUnselected(p0: TabLayout.Tab?) {
            }

            override fun onTabSelected(p0: TabLayout.Tab?) {
                val position=p0!!.position
                Log.d("Position","position is $position")
                Toast.makeText(this@MainActivity,"Select position is :$position",Toast.LENGTH_SHORT).show()
            }

        })
        for(i in 1 .. 4){
            val tabView= LayoutInflater.from(this).inflate(R.layout.tab_item,null)
            val textView=tabView.findViewById<TextView>(R.id.mTvBottom)
            textView.text="Home"
            val drawable=resources.getDrawable(R.drawable.home)
            drawable.setBounds(0,0,drawable.intrinsicWidth,drawable.intrinsicHeight)
            textView.setCompoundDrawables(null,drawable,null,null)
            mTabLayout.addTab(mTabLayout.newTab().setCustomView(tabView))
        }


    }

    fun fromHtml(source: String): Spanned {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(source, Html.FROM_HTML_MODE_LEGACY)
        } else {
            Html.fromHtml(source)
        }
    }
}
