package com.chainspower.mytab

import android.animation.ObjectAnimator
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_ktxcore_study.*

class KTXCoreStudyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ktxcore_study)
        animation()
    }

    private fun animation() {
        mBtnAnimation.setOnClickListener {


        }

        val animation=ObjectAnimator.ofFloat(mView,"translationX",0f,240f)




    }
}
